﻿USE master
GO

CREATE DATABASE PE_DBI202
GO

USE PE_DBI202
GO

CREATE TABLE Clients (
	Id INT PRIMARY KEY IDENTITY,
	FirstName NVARCHAR(50) NOT NULL,
	LastName NVARCHAR(50) NOT NULL
)
GO

CREATE TABLE AccountTypes (
	Id INT PRIMARY KEY IDENTITY,
	[Name] NVARCHAR(50) NOT NULL
)
GO

INSERT INTO Clients (FirstName, LastName) VALUES
('Adam', 'Smith'),
('Peter', 'Parker'),
('David', 'Sampson'),
('Mary', 'Bush'),
('George', 'Wan')

INSERT INTO AccountTypes (Name) VALUES
('Checking'),
('Fixed saving'),
('Flexible saving')

2.
CREATE TABLE Accounts (
	Id INT PRIMARY KEY IDENTITY,
	AccountTypeId INT FOREIGN KEY REFERENCES AccountTypes(Id),
	Balance DECIMAL(15, 2) NOT NULL DEFAULT(0),
	ClientId INT FOREIGN KEY REFERENCES Clients(Id)
)

/* SV phải add số liệu thỏa mãn các Foreign keys đã định nghĩa */
INSERT INTO Accounts (ClientId, AccountTypeId, Balance) VALUES
(1, 1, 652),
(2, 3, 270.93),
(5, 2, 507.01),
(4, 1, 59.30),
(4, 2, 478.52)

3. 
CREATE PROCEDURE sp_WithdrawMoney
                 @accountId   INT,
                 @moneyAmount DECIMAL(15, 2)
AS
     BEGIN
         IF(@moneyAmount < 0)
             BEGIN
                 RAISERROR('Cannot withdraw negative value', 16, 1);
			 END;
         ELSE
             BEGIN
                 IF(@accountId IS NULL OR @moneyAmount IS NULL)
                     BEGIN
                         RAISERROR('Missing value', 16, 1);
                     END;
             END;
         BEGIN TRANSACTION;
           UPDATE Accounts
           SET
               Balance -= @moneyAmount
           WHERE Id = @accountId;
         IF(@@ROWCOUNT < 1)
             BEGIN
                 RAISERROR('Account does not exist', 16, 1);
             END;
         ELSE
             BEGIN
                 IF(0 >
                   (
                       SELECT Balance
                       FROM Accounts
                       WHERE Id = @accountId
                   ))
                     BEGIN
                         ROLLBACK;
                         RAISERROR('Balance is not enough', 16, 1);
                     END;
             END;
         COMMIT;
     END;

4.
CREATE TABLE NotificationEmails
(
             Id        INT NOT NULL IDENTITY,
             Recipient INT NOT NULL,
             Subject   NVARCHAR(50) NOT NULL,
             Content      NVARCHAR(255) NOT NULL,
             CONSTRAINT PK_NotificationEmails PRIMARY KEY(Id)
)

CREATE TRIGGER tr_NotificationEmails ON Accounts
AFTER UPDATE
AS
     BEGIN
         INSERT INTO NotificationEmails(Recipient, Subject, Content)
         VALUES
         (
         (
             SELECT Id
             FROM inserted
         ),
         CONCAT('Update on account: ',
               (
                   SELECT Id
                   FROM inserted
               )),
         CONCAT('On ', FORMAT(GETDATE(), 'dd-MM-yyyy HH:mm'), ' your balance was changed from ',
               (
                   SELECT Balance
                   FROM deleted
               ), ' to ',
               (
                   SELECT Balance
                   FROM inserted
               ), '.')
         );
     END;

5.
CREATE VIEW ClientsWithBalanceHigherThan300 AS
SELECT c.FirstName AS [First Name], c.LastName AS [Last Name]
FROM Clients AS c JOIN Accounts AS a ON c.Id = a.ClientId
GROUP BY c.FirstName, c.LastName
HAVING SUM(a.Balance)>300
