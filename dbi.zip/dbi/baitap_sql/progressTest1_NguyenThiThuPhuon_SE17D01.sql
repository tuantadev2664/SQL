USE ReportManage
INSERT  INTO Users(Username,Password,Name,Gender,BirthDate,Email) VALUES (N'Thu Ph??ng',N'p12345','F','2000-01-01'18,'phuong12@gmail.com')