﻿create database CLUB_Mng
go
use CLUB_Mng
go
create table tblMembers
(
	memID varchar (10) primary key,
	FullName nvarchar(40) not null,
	phone varchar(10) not null Check(phone like '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
	memAdd nvarchar(80),
	DOB date,
	Email varchar(50)
);
go
Insert into tblmembers values('M001',N'Nguyễn Thanh Thúy','0905678541',N'47 Trần Văn Trà- Đà Nẵng','2002-05-18','thuy123@gmail.com')
Insert into tblmembers values('M002',N'Trần Minh Trung','0905678678',N'20 Lê Văn Hiến- Đà Nẵng','2000-03-10','trungmt@gmail.com')
Insert into tblmembers values('M003',N'Lâm Thanh Tân','0905679878',N'85 Phù Đổng- Đà Nẵng','2001-05-17','lamthanhtan@gmail.com')
go
create table tblClubs
(
	clubID int IDENTITY (1, 1) Primary key,
	clubName nvarchar(40) not null,
	creation_date date,
	club_description nvarchar (100)	
);
go
Insert into tblClubs values(N'Câu lạc bộ lập trình','2020-09-05',N'Câu lạc bộ dành cho các bạn yêu thích lập trình', 'M001')
Insert into tblClubs values(N'Câu lạc bộ bóng đá','2019-03-07',N'Câu lạc bộ dành cho các bạn yêu bóng đá', 'M002')
Insert into tblClubs values(N'Câu lạc bộ khiêu vũ','2020-10-08',N'Câu lac bộ dành cho các bạn yêu thích khiêu vũ', 'M003')
go
